const TAREFAS = [
    {
        titulo:'Revisar código crítico',
        descrição: 'Revisar bugs críticos no módulo principal',
        prioridade: 'Alta',
        data: '12/12/12',
        resposanvel: ['Luisa', 'Fabiana'],

    },

    {
        titulo:'Implementar autenticação',
        descrição: 'Adicionar sistema de login seguro',
        prioridade: 'Média',
        data: '12/12/12',
        resposanvel: ['Alice', 'Carlos'],
    },
    
    {
        titulo:'Implementar autenticação',
        descrição: 'Adicionar sistema de login seguro',
        prioridade: 'Média',
        data: '12/12/12',
        resposanvel: ['Alice', 'Carlos'],
    },
    
    {
        titulo:'Implementar autenticação',
        descrição: 'Adicionar sistema de login seguro',
        prioridade: 'Média',
        data: '12/12/12',
        resposanvel: ['Alice', 'Carlos'],
    },
    
    {
        titulo:'Implementar autenticação',
        descrição: 'Adicionar sistema de login seguro',
        prioridade: 'Média',
        data: '12/12/12',
        resposanvel: ['Alice', 'Carlos'],
    }
]